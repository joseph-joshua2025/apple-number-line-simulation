let position = 0;
let steps = [];
let currentStep = 0;
let marker;

function startSimulation() {
    const first = parseInt(document.getElementById('firstNumber').value);
    const second = parseInt(document.getElementById('secondNumber').value);
    const operation = document.getElementById('operation').value;
    const line = document.getElementById('numberLine');
    document.getElementById('result').textContent = '';
    line.innerHTML = '';

    for (let i = -10; i <= 10; i++) {
        const div = document.createElement('div');
        div.className = 'number';
        div.id = 'pos' + i;
        div.innerHTML = `<div>${i}</div>`;
        line.appendChild(div);
    }

    position = first;
    currentStep = 0;
    steps = [];

    const isAddition = operation === '+';
    const move = isAddition ? second : -second;
    const stepCount = Math.abs(move);
    const direction = move > 0 ? 1 : -1;

    for (let i = 0; i < stepCount; i++) {
        steps.push(direction);
    }

    updateMarker(first);
}

function updateMarker(pos) {
    if (marker) marker.remove();
    const container = document.getElementById('pos' + pos);
    if (container) {
        marker = document.createElement('img');
        marker.src = pos >= 0 ? 'assets/upright_apple.png' : 'assets/inverted_apple.png';
        marker.className = 'apple';
        container.appendChild(marker);
        container.classList.add('current');
    }
}

function nextStep() {
    if (currentStep < steps.length) {
        position += steps[currentStep];
        currentStep++;
        updateMarker(position);
    } else {
        document.getElementById('result').textContent = "Result: " + position;
    }
}