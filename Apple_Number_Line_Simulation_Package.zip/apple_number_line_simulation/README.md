# Apple Number Line Simulation

This is an interactive tool to help students understand the addition and subtraction of directed numbers using apple metaphors on a number line.

## Instructions

1. Choose the first number, operation (+ or -), and the second number.
2. Click "Start" to place the apple on the number line.
3. Click "Next Step" to move the apple step-by-step.
4. Result will be shown after the final move.

## Hosting

To host this online with GitHub Pages:
- Create a new repository and upload all files including the `assets` folder.
- Go to **Settings > Pages**, choose branch `main` and root `/`.
- Your site will be live at `https://yourusername.github.io/repository-name/`.